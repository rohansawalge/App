// Bulk-add PYQs or notes to your server from a JSON file.
// Usage:  node tools/import-content.mjs content.json https://YOUR-WORKER.workers.dev YOUR_ADMIN_KEY
import { readFile } from "node:fs/promises";

const [, , file, api, key] = process.argv;
if (!file || !api || !key) {
  console.log("Usage: node tools/import-content.mjs content.json https://YOUR-WORKER.workers.dev YOUR_ADMIN_KEY");
  process.exit(1);
}
const items = JSON.parse(await readFile(file, "utf8"));
let ok = 0;
for (const [i, it] of items.entries()) {
  const r = await fetch(api.replace(/\/+$/, "") + "/content", {
    method: "POST",
    headers: { "content-type": "application/json", "x-admin-key": key },
    body: JSON.stringify({ createdAt: Date.now() + i, ...it }),
  });
  if (r.ok) ok++;
  else console.log(`Item ${i + 1} failed:`, r.status, await r.text());
}
console.log(`Added ${ok} of ${items.length} items.`);
