/* Native-style app shell: Home, Subjects, Practice, Tutor, Saved, Search, topic pages */
(function () {
  "use strict";
  if (!window.GATE_APP) return;

  var META = {
    aptitude: { ic: "🧠", c: "#7B61FF" }, maths: { ic: "∑", c: "#2F6FDB" }, mechanics: { ic: "⚖️", c: "#0F8B8D" },
    som: { ic: "🏗️", c: "#C9362C" }, tom: { ic: "⚙️", c: "#5B6770" }, vibrations: { ic: "〰️", c: "#8E44AD" },
    design: { ic: "🔩", c: "#B7791F" }, fluids: { ic: "💧", c: "#1D8FD1" }, heat: { ic: "🔥", c: "#E4572E" },
    thermo: { ic: "🌡️", c: "#D1495B" }, manufacturing: { ic: "🏭", c: "#3D7A3D" }, industrial: { ic: "📊", c: "#3B5BA5" }
  };
  var ICON = {
    home: '<path d="M3 11l9-8 9 8"/><path d="M5 10v10h14V10"/>',
    book: '<path d="M4 4h7a3 3 0 0 1 3 3v13a2 2 0 0 0-2-2H4z"/><path d="M20 4h-7a3 3 0 0 0-3 3v13a2 2 0 0 1 2-2h8z"/>',
    target: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/>',
    chat: '<path d="M21 12a8 8 0 0 1-11.6 7.1L4 20l1-4.6A8 8 0 1 1 21 12z"/>',
    save: '<path d="M6 3h12v18l-6-4-6 4z"/>',
    back: '<path d="M15 18l-6-6 6-6"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="M21 21l-4.5-4.5"/>'
  };
  function svg(n) { return '<svg viewBox="0 0 24 24" aria-hidden="true">' + ICON[n] + "</svg>"; }
  function esc(t) { return String(t == null ? "" : t).replace(/[&<>"]/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]; }); }
  function load(k, d) { try { var v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch (e) { return d; } }
  function save(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} }

  var read = load("gm_read", {}), saved = load("gm_saved", []), pyqs = load("gm_pyq", {}), last = load("gm_last", null);

  /* ---------- build the content index from the existing notes ---------- */
  var SUBJ = [], UNITS = {}, ORDER = [];
  function addUnits(art, sid) {
    var list = [], i = 0;
    Array.prototype.forEach.call(art.children, function (n) {
      if (n.tagName !== "SECTION" || n.classList.contains("subjhead") || n.classList.contains("deephead")) return;
      i++;
      if (!n.id) n.id = sid + "-u" + i;
      var hs = n.querySelectorAll("h2,h3"), title = hs.length ? hs[0].textContent.trim() : "Concepts";
      var kind = n.classList.contains("rev") ? "rev" : /-pyq$/.test(n.id) ? "pyq" : n.classList.contains("added") ? "added" : n.classList.contains("manage") ? "manage" : "topic";
      if (kind === "rev") title = "Revision sheet";
      if (kind === "pyq") title = "Previous year questions";
      if (kind === "added") title = "New questions and notes";
      var sub = [];
      if (kind === "topic" && !n.classList.contains("topic") && hs.length > 1) { for (var k = 1; k < hs.length && sub.length < 3; k++) if (hs[k].tagName === "H3") sub.push(hs[k].textContent.trim()); }
      var ph = document.createComment("u:" + n.id);
      n.parentNode.insertBefore(ph, n);
      var u = { id: n.id, el: n, ph: ph, sid: sid, title: title, kind: kind, sub: sub.join(" · "), sims: n.querySelectorAll(".sim").length, qs: n.querySelectorAll(".pyq").length, text: "" };
      UNITS[u.id] = u; list.push(u); if (sid !== "overview") ORDER.push(u.id);
    });
    return list;
  }
  Array.prototype.forEach.call(document.querySelectorAll("article.subj"), function (a) {
    var head = a.querySelector(".subjhead h2"), syl = a.querySelector(".syl");
    var s = { id: a.id, name: head ? head.textContent.trim() : "About GATE", syl: syl ? syl.textContent.replace(/^Syllabus:\s*/, "") : "", units: [] };
    s.units = addUnits(a, a.id);
    if (a.id !== "overview") SUBJ.push(s);
    else window.__gmOverview = s;
  });
  var SMAP = {}; SUBJ.forEach(function (s) { SMAP[s.id] = s; });
  function learnUnits(s) { return s.units.filter(function (u) { return u.kind === "topic"; }); }
  function pct(s) { var l = learnUnits(s); if (!l.length) return 0; return Math.round(100 * l.filter(function (u) { return read[u.id]; }).length / l.length); }
  function visible(u) { return !(u.kind === "added" && u.el.hidden) && !(u.kind === "manage" && u.el.hidden); }

  /* ---------- shell DOM ---------- */
  document.body.classList.add("gm-app");
  var app = document.createElement("div"); app.id = "app";
  app.innerHTML = '<header class="appbar"><button class="iconbtn" id="a-back" aria-label="Back">' + svg("back") + '</button><h1 id="a-title">GATE ME</h1><button class="iconbtn" id="a-search" aria-label="Search">' + svg("search") + '</button><button class="iconbtn" id="a-save" aria-label="Bookmark">' + svg("save") + '</button></header><div id="view"></div>';
  var tabs = document.createElement("nav"); tabs.className = "tabs"; tabs.setAttribute("aria-label", "Main");
  [["home", "#/", "Home"], ["book", "#/subjects", "Subjects"], ["target", "#/practice", "Practice"], ["chat", "#/tutor", "Tutor"], ["save", "#/saved", "Saved"]].forEach(function (t) {
    var a = document.createElement("a"); a.href = t[1]; a.dataset.tab = t[1]; a.innerHTML = '<span class="pill">' + svg(t[0]) + "</span>" + t[2]; tabs.appendChild(a);
  });
  document.body.insertBefore(app, document.body.firstChild);
  document.body.appendChild(tabs);
  var view = document.getElementById("view"), title = document.getElementById("a-title"), backB = document.getElementById("a-back"), saveB = document.getElementById("a-save"), searchB = document.getElementById("a-search");
  backB.onclick = function () { history.length > 1 ? history.back() : (location.hash = "#/"); };
  searchB.onclick = function () { location.hash = "#/search"; };

  var mounted = null, tutorMounted = false;
  function unmount() {
    if (mounted) { mounted.ph.parentNode.insertBefore(mounted.el, mounted.ph.nextSibling); mounted = null; }
    var t = document.getElementById("tutor");
    if (tutorMounted && t) { t.classList.remove("app-tutor", "open"); document.body.appendChild(t); tutorMounted = false; }
    document.body.classList.remove("on-unit");
    view.className = "";
  }
  function bar(p, c) { return '<div class="pbar"><i style="width:' + p + "%;background:" + (c || "var(--accent)") + '"></i></div>'; }
  function ring(p) { var r = 36, L = 2 * Math.PI * r; return '<svg class="ring" viewBox="0 0 84 84"><circle cx="42" cy="42" r="' + r + '" style="stroke:var(--grid)"/><circle cx="42" cy="42" r="' + r + '" style="stroke:var(--accent)" stroke-linecap="round" stroke-dasharray="' + (L * p / 100) + " " + L + '" transform="rotate(-90 42 42)"/><text x="42" y="47" text-anchor="middle" style="font:700 17px var(--sans);fill:var(--ink)">' + p + "%</text></svg>"; }
  function setBar(t, opts) {
    title.textContent = t; backB.style.visibility = opts.back ? "visible" : "hidden";
    saveB.style.display = opts.unit ? "" : "none"; searchB.style.display = opts.search ? "" : "none";
    if (opts.unit) { var on = saved.indexOf(opts.unit) >= 0; saveB.classList.toggle("on", on); saveB.onclick = function () { var i = saved.indexOf(opts.unit); i >= 0 ? saved.splice(i, 1) : saved.push(opts.unit); save("gm_saved", saved); saveB.classList.toggle("on", i < 0); }; }
    Array.prototype.forEach.call(tabs.children, function (a) { a.classList.toggle("on", a.dataset.tab === opts.tab); });
  }
  function page(html) { view.innerHTML = '<div class="page">' + html + "</div>"; window.scrollTo(0, 0); }
  function unitRow(u, n) {
    var s = SMAP[u.sid] || window.__gmOverview, m = META[u.sid] || { ic: "ℹ️", c: "#5B6770" };
    var lead = n ? '<span class="num' + (read[u.id] ? " done" : "") + '">' + (read[u.id] ? "✓" : n) + "</span>" : '<span class="ic" style="background:' + m.c + '22">' + m.ic + "</span>";
    var badges = (u.sims ? '<span class="badge sim">' + u.sims + " sim" + (u.sims > 1 ? "s" : "") + "</span>" : "") + (u.qs ? '<span class="badge q">' + u.qs + " Qs</span>" : "");
    var sub = n ? esc(u.sub) : esc(s ? s.name : "");
    return '<a class="row" href="#/u/' + u.id + '">' + lead + '<span class="tx"><b>' + esc(u.title) + "</b>" + (badges ? '<span style="display:block;margin-top:3px">' + badges + "</span>" : "") + (sub ? "<small>" + sub + "</small>" : "") + '</span><span class="chev">›</span></a>';
  }

  /* ---------- screens ---------- */
  function home() {
    setBar("GATE ME Notes", { tab: "#/", search: true });
    var all = [], done = 0; SUBJ.forEach(function (s) { learnUnits(s).forEach(function (u) { all.push(u); if (read[u.id]) done++; }); });
    var tq = 0; SUBJ.forEach(function (s) { s.units.forEach(function (u) { if (u.kind === "pyq" || u.kind === "added") tq += u.el.querySelectorAll(".pyq").length; }); });
    var ok = Object.keys(pyqs).filter(function (k) { return pyqs[k] === 1; }).length, p = all.length ? Math.round(100 * done / all.length) : 0;
    var lu = last && UNITS[last], admin = false; try { admin = !!localStorage.getItem("gm_admin"); } catch (e) {}
    var h = '<div class="hello"><h2 id="h-title">Let’s crack GATE.</h2><p>Mechanical Engineering · every topic, live</p></div>' +
      '<a class="searchbox" href="#/search">' + svg("search") + "Search topics, formulas, questions</a>" +
      '<div class="card2 prog">' + ring(p) + '<div class="stats"><b>Your progress</b><span><b>' + done + "</b> of " + all.length + " topics completed</span><span><b>" + ok + "</b> of " + tq + " PYQs solved</span><span><b>" + saved.length + "</b> saved topics</span></div></div>";
    if (lu) { var m = META[lu.sid] || { ic: "ℹ️", c: "#5B6770" }; h += '<div class="sect"><h3>Continue</h3></div><a class="card2 cont" href="#/u/' + lu.id + '"><span class="ic" style="background:' + m.c + '22">' + m.ic + "</span><span><small>" + esc((SMAP[lu.sid] || {}).name || "") + "</small><b>" + esc(lu.title) + "</b></span></a>"; }
    h += '<div class="quick"><a href="#/practice"><span class="ic">🎯</span>Practice</a><a href="#/tutor"><span class="ic">💬</span>Ask tutor</a><a href="#/revise"><span class="ic">⚡</span>Revision</a>' + (admin ? '<a href="#/u/manage"><span class="ic">➕</span>Add content</a>' : '<a href="#/about"><span class="ic">ℹ️</span>About GATE</a>') + "</div>";
    h += '<div class="sect"><h3>Subjects</h3><a href="#/subjects">See all</a></div><div class="grid2">';
    SUBJ.forEach(function (s) { var m = META[s.id], pp = pct(s); h += '<a class="scard" href="#/s/' + s.id + '"><span class="ic" style="background:' + m.c + '22">' + m.ic + "</span><b>" + esc(s.name) + "</b><small>" + learnUnits(s).length + " topics · " + pp + "%</small>" + bar(pp, m.c) + "</a>"; });
    page(h + "</div>");
    var ht = document.getElementById("h-title"), taps = [];
    ht.addEventListener("click", function () { var now = Date.now(); taps = taps.filter(function (t) { return now - t < 3000; }); taps.push(now); if (taps.length >= 5) { taps = []; var k = prompt(admin ? "Admin mode is on. Leave empty and press OK to sign out." : "Enter the admin key to add content:"); if (k === null) return; try { k ? localStorage.setItem("gm_admin", k.trim()) : localStorage.removeItem("gm_admin"); } catch (e) {} location.reload(); } });
  }
  function subjects() {
    setBar("Subjects", { tab: "#/subjects", search: true });
    var h = '<div class="rlist" style="margin-top:8px">';
    SUBJ.forEach(function (s) { var m = META[s.id], pp = pct(s); h += '<a class="row" href="#/s/' + s.id + '"><span class="ic" style="background:' + m.c + '22">' + m.ic + '</span><span class="tx"><b>' + esc(s.name) + "</b><small>" + learnUnits(s).length + " topics · " + pp + "% done</small>" + bar(pp, m.c) + '</span><span class="chev">›</span></a>'; });
    page(h + "</div>");
  }
  function subject(id) {
    var s = SMAP[id]; if (!s) return home();
    var m = META[id], pp = pct(s), learn = learnUnits(s);
    setBar(s.name, { tab: "#/subjects", back: true, search: true });
    var pq = s.units.filter(function (u) { return u.kind === "pyq"; })[0], rv = s.units.filter(function (u) { return u.kind === "rev"; })[0], ad = s.units.filter(function (u) { return u.kind === "added" && visible(u); })[0];
    var h = '<div class="hero2" style="background:linear-gradient(135deg,' + m.c + "," + m.c + 'cc)"><span class="ic">' + m.ic + "</span><h2>" + esc(s.name) + "</h2><p>" + learn.filter(function (u) { return read[u.id]; }).length + " of " + learn.length + " topics done · " + pp + "%</p>" + bar(pp) + "</div>";
    h += '<div class="chips2">' + (rv ? '<a href="#/u/' + rv.id + '">⚡ Revision sheet</a>' : "") + (pq ? '<a href="#/u/' + pq.id + '">🎯 PYQs (' + pq.qs + ")</a>" : "") + (ad ? '<a href="#/u/' + ad.id + '">🆕 New content</a>' : "") + "</div>";
    if (s.syl) h += '<details class="syl2"><summary>Syllabus</summary><p>' + esc(s.syl) + "</p></details>";
    h += '<div class="sect"><h3>Topics</h3><small style="color:var(--muted)">' + learn.length + "</small></div><div class=\"rlist\">";
    learn.forEach(function (u, i) { h += unitRow(u, i + 1); });
    page(h + "</div>");
  }
  function unit(id) {
    var u = UNITS[id]; if (!u) return home();
    var s = SMAP[u.sid] || window.__gmOverview, m = META[u.sid] || { ic: "ℹ️", c: "#5B6770" };
    setBar(s.name, { back: true, unit: u.id, tab: u.kind === "pyq" ? "#/practice" : "#/subjects" });
    if (u.kind === "topic") { last = u.id; save("gm_last", last); }
    var seq = s.units.filter(function (x) { return x.kind === "topic"; }), idx = seq.indexOf(u), prev = idx > 0 ? seq[idx - 1] : null, next = idx >= 0 && idx < seq.length - 1 ? seq[idx + 1] : null;
    var mins = Math.max(1, Math.round(u.el.textContent.split(/\s+/).length / 200));
    view.className = "subj on";
    view.innerHTML = '<div class="page"><div class="subjhead" style="display:none"><h2>' + esc(s.name) + '</h2></div><div class="uhead"><a class="chip" href="#/s/' + u.sid + '" style="background:' + m.c + '">' + m.ic + " " + esc(s.name) + "</a><h2>" + esc(u.title) + "</h2><small>" + (u.sims ? u.sims + " simulation" + (u.sims > 1 ? "s" : "") + " · " : "") + (u.qs ? u.qs + " questions · " : "") + mins + ' min read</small></div><div class="unit-body"></div><div id="u-foot"></div></div>';
    view.querySelector(".unit-body").appendChild(u.el); mounted = u;
    document.body.classList.add("on-unit");
    var f = "";
    if (u.kind === "topic") f += '<button class="donebtn' + (read[u.id] ? " is" : "") + '" id="u-done">' + (read[u.id] ? "✓ Completed" : "Mark as completed") + "</button>";
    if (prev || next) f += '<div class="pager">' + (prev ? '<a href="#/u/' + prev.id + '"><small>‹ Previous</small><b>' + esc(prev.title) + "</b></a>" : "<span></span>") + (next ? '<a class="next" href="#/u/' + next.id + '"><small>Next ›</small><b>' + esc(next.title) + "</b></a>" : "<span></span>") + "</div>";
    document.getElementById("u-foot").innerHTML = f;
    var db = document.getElementById("u-done");
    if (db) db.onclick = function () { read[u.id] = !read[u.id]; if (!read[u.id]) delete read[u.id]; save("gm_read", read); db.classList.toggle("is", !!read[u.id]); db.textContent = read[u.id] ? "✓ Completed" : "Mark as completed"; };
    window.scrollTo(0, 0);
    requestAnimationFrame(function () { if (window.__gmRender) window.__gmRender(); var t = pendingScroll && document.getElementById(pendingScroll); if (t) t.scrollIntoView({ block: "start" }); pendingScroll = null; });
  }
  function practice() {
    setBar("Practice", { tab: "#/practice", search: true });
    var h = '<div class="hello"><h2>Previous year questions</h2><p>Solve, check your answer, then open the solution.</p></div><div class="rlist">';
    SUBJ.forEach(function (s) {
      var m = META[s.id], us = s.units.filter(function (u) { return u.kind === "pyq" || (u.kind === "added" && visible(u)); });
      us.forEach(function (u) {
        var n = u.el.querySelectorAll(".pyq").length; if (!n) return;
        var c = 0; for (var i = 0; i < n; i++) if (pyqs[u.id + ":" + i] === 1) c++;
        h += '<a class="row" href="#/u/' + u.id + '"><span class="ic" style="background:' + m.c + '22">' + m.ic + '</span><span class="tx"><b>' + esc(s.name) + (u.kind === "added" ? " · new" : "") + "</b><small>" + c + " of " + n + " solved</small>" + bar(Math.round(100 * c / n), m.c) + '</span><span class="chev">›</span></a>';
      });
    });
    page(h + "</div>");
  }
  function revise() {
    setBar("Revision", { back: true, tab: "#/", search: true });
    var h = '<div class="hello"><h2>Last-minute revision</h2><p>Every syllabus line, one sheet per subject.</p></div><div class="rlist">';
    SUBJ.forEach(function (s) { var r = s.units.filter(function (u) { return u.kind === "rev"; })[0]; if (r) h += unitRow(r); });
    page(h + "</div>");
  }
  function about() {
    setBar("About GATE", { back: true, tab: "#/" });
    var h = '<div class="rlist" style="margin-top:8px">';
    window.__gmOverview.units.forEach(function (u) { if (visible(u)) h += unitRow(u); });
    page(h + "</div>");
  }
  function savedV() {
    setBar("Saved", { tab: "#/saved", search: true });
    var us = saved.map(function (id) { return UNITS[id]; }).filter(Boolean);
    page(us.length ? '<div class="rlist" style="margin-top:8px">' + us.map(function (u) { return unitRow(u); }).join("") + "</div>" : '<div class="empty"><div>🔖</div>Tap the bookmark icon on any topic to save it here.</div>');
  }
  function searchV() {
    setBar("Search", { back: true, tab: "" });
    page('<input class="sinput" id="s-in" type="search" placeholder="Search topics, formulas, questions" aria-label="Search"><div class="rlist" id="s-out"></div>');
    var inp = document.getElementById("s-in"), out = document.getElementById("s-out");
    Object.keys(UNITS).forEach(function (k) { var u = UNITS[k]; if (!u.text) u.text = (u.title + " " + u.el.textContent).toLowerCase(); });
    function run() {
      var q = inp.value.trim().toLowerCase(); if (q.length < 2) { out.innerHTML = '<div class="empty"><div>🔎</div>Try “Mohr”, “EOQ”, “Otto”, “Coriolis”…</div>'; return; }
      var res = []; Object.keys(UNITS).forEach(function (k) { var u = UNITS[k]; if (!visible(u)) return; var t = u.title.toLowerCase().indexOf(q) >= 0 ? 2 : u.text.indexOf(q) >= 0 ? 1 : 0; if (t) res.push([t, u]); });
      res.sort(function (a, b) { return b[0] - a[0]; });
      out.innerHTML = res.length ? res.slice(0, 40).map(function (r) { return unitRow(r[1]); }).join("") : '<div class="empty">No matches.</div>';
    }
    inp.addEventListener("input", run); run(); setTimeout(function () { inp.focus(); }, 60);
  }
  function tutor() {
    setBar("GATE tutor", { tab: "#/tutor" });
    var t = document.getElementById("tutor");
    page('<div id="t-slot"></div>');
    if (!t) return;
    var fab = document.getElementById("tutor-fab");
    if (!fab || fab.style.display === "none") { view.innerHTML = '<div class="page empty"><div>💬</div>The tutor needs an internet connection and a configured server. Ask your teacher for the latest app.</div>'; return; }
    document.getElementById("t-slot").appendChild(t); t.classList.add("app-tutor", "open"); tutorMounted = true;
    var ctx = document.getElementById("t-ctx"); if (ctx) ctx.textContent = "Ask anything about GATE Mechanical.";
  }

  /* ---------- router ---------- */
  var pendingScroll = null;
  function route() {
    unmount();
    var h = decodeURIComponent(location.hash.slice(1) || "/"), p = h.split("/");
    if (h === "/" || h === "") return home();
    if (p[1] === "subjects") return subjects();
    if (p[1] === "s") return subject(p[2]);
    if (p[1] === "u") return unit(p.slice(2).join("/"));
    if (p[1] === "practice") return practice();
    if (p[1] === "tutor") return tutor();
    if (p[1] === "saved") return savedV();
    if (p[1] === "search") return searchV();
    if (p[1] === "revise") return revise();
    if (p[1] === "about") return about();
    /* legacy in-page links like #sim-lamp or #som */
    if (SMAP[h]) { location.replace("#/s/" + h); return; }
    var el = document.getElementById(h);
    if (el) { var n = el; while (n && !(n.id && UNITS[n.id])) n = n.parentElement; if (n) { pendingScroll = h === n.id ? null : h; location.replace("#/u/" + n.id); return; } }
    home();
  }
  window.addEventListener("hashchange", route);

  /* track PYQ answers for progress */
  document.addEventListener("click", function (e) {
    var q = e.target.closest && e.target.closest(".pyq"); if (!q) return;
    if (!(e.target.closest(".check") || e.target.closest(".opts button"))) return;
    setTimeout(function () {
      var fb = q.querySelector(".fb"); if (!fb || !mounted) return;
      var i = Array.prototype.indexOf.call(mounted.el.querySelectorAll(".pyq"), q);
      var k = mounted.id + ":" + i, v = fb.classList.contains("ok") ? 1 : fb.classList.contains("bad") ? 0 : null;
      if (v === null) return; if (pyqs[k] !== 1) { pyqs[k] = v; save("gm_pyq", pyqs); }
    }, 0);
  }, true);

  route();
})();
