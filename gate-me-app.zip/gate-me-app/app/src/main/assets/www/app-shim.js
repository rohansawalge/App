/* Makes the notes page work inside the Android app without a Claude account.
   The page asks for "sample" (tutor), "db" (added content) and "user" (admin check);
   this file answers those requests using your own server instead of claude.ai. */
(function () {
  if (window.claude) return;
  var CFG = window.GATE_CONFIG || {};
  var API = String(CFG.API_URL || "").replace(/\/+$/, "");
  var configured = !!API && API.indexOf("YOUR-") < 0;

  var dev = null;
  try { dev = localStorage.getItem("gm_dev"); } catch (e) {}
  if (!dev) {
    dev = Math.random().toString(36).slice(2) + Date.now().toString(36);
    try { localStorage.setItem("gm_dev", dev); } catch (e) {}
  }
  function adminKey() { try { return localStorage.getItem("gm_admin") || ""; } catch (e) { return ""; } }

  async function sample(input, opts) {
    opts = opts || {};
    var messages = typeof input === "string" ? [{ role: "user", content: input }] : input;
    var r;
    try {
      r = await fetch(API + "/chat", {
        method: "POST",
        headers: { "content-type": "application/json", "x-device": dev },
        body: JSON.stringify({ messages: messages }),
        signal: opts.signal
      });
    } catch (e) {
      throw { code: e && e.name === "AbortError" ? "cancelled" : "upstream_error", message: "No internet connection" };
    }
    var j = {};
    try { j = await r.json(); } catch (e) {}
    if (!r.ok) throw { code: r.status === 429 ? "rate_limited" : "upstream_error", message: j.error || ("HTTP " + r.status) };
    var text = j.text || "";
    if (opts.onText) opts.onText({ text: text, delta: text });
    return { text: text, truncated: !!j.truncated };
  }

  var cache = [];
  try { cache = JSON.parse(localStorage.getItem("gm_content") || "[]"); } catch (e) {}
  var listeners = [];
  function snap(list) {
    return { size: list.length, empty: !list.length, docs: list.map(function (it) { return { id: it.id, exists: true, data: function () { return it; } }; }) };
  }
  async function refresh() {
    try {
      var r = await fetch(API + "/content");
      if (r.ok) {
        var j = await r.json();
        cache = (j.items || []).sort(function (a, b) { return (a.createdAt || 0) - (b.createdAt || 0); });
        try { localStorage.setItem("gm_content", JSON.stringify(cache)); } catch (e) {}
      }
    } catch (e) { /* offline: keep the cached copy */ }
    listeners.forEach(function (f) { f(snap(cache)); });
  }
  var query = {
    orderBy: function () { return query; },
    where: function () { return query; },
    limit: function () { return query; },
    get: async function () { await refresh(); return snap(cache); },
    onSnapshot: function (cb) {
      listeners.push(cb);
      setTimeout(function () { cb(snap(cache)); refresh(); }, 0);
      return function () { listeners = listeners.filter(function (x) { return x !== cb; }); };
    },
    add: async function (d) {
      var r = await fetch(API + "/content", { method: "POST", headers: { "content-type": "application/json", "x-admin-key": adminKey() }, body: JSON.stringify(d) });
      var j = {};
      try { j = await r.json(); } catch (e) {}
      if (!r.ok) throw { code: "denied", message: r.status === 401 ? "wrong admin key" : (j.error || "HTTP " + r.status) };
      await refresh();
      return { id: j.id };
    }
  };
  var db = {
    collection: function () { return query; },
    doc: function (path) {
      var id = String(path).split("/").pop();
      return {
        delete: async function () {
          var r = await fetch(API + "/content/" + encodeURIComponent(id), { method: "DELETE", headers: { "x-admin-key": adminKey() } });
          if (!r.ok) throw { code: "denied", message: r.status === 401 ? "wrong admin key" : "HTTP " + r.status };
          await refresh();
        }
      };
    }
  };
  var user = { canEdit: function () { return !!adminKey(); }, isOwner: function () { return !!adminKey(); }, can: function () { return !!adminKey(); } };

  window.claude = {
    use: async function (name) {
      if (name === "sample") return configured ? sample : null;
      if (name === "db") return configured ? db : null;
      if (name === "user") return user;
      return null;
    }
  };

  /* Admin unlock: tap the big title on the Overview page 5 times quickly. */
  document.addEventListener("DOMContentLoaded", function () {
    var h = document.querySelector("#overview h1");
    if (!h) return;
    var taps = [];
    h.addEventListener("click", function () {
      var now = Date.now();
      taps = taps.filter(function (t) { return now - t < 3000; });
      taps.push(now);
      if (taps.length >= 5) {
        taps = [];
        var k = prompt(adminKey() ? "Admin mode is on. Leave empty and press OK to sign out." : "Enter the admin key to add content:");
        if (k === null) return;
        try { k ? localStorage.setItem("gm_admin", k.trim()) : localStorage.removeItem("gm_admin"); } catch (e) {}
        location.reload();
      }
    });
  });
})();
