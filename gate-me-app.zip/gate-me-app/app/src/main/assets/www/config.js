/* Paste your Cloudflare Worker URL here after deploying the server (see README, step 2). */
window.GATE_CONFIG = {
  API_URL: "https://YOUR-WORKER.YOUR-SUBDOMAIN.workers.dev"
};
