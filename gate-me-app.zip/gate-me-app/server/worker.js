/**
 * GATE ME Notes server (Cloudflare Worker).
 * - POST /chat            -> asks Claude through the Claude API (your key stays here, never in the app)
 * - GET  /content         -> list of added PYQs and notes
 * - POST /content         -> add an item (needs the admin key)
 * - DELETE /content/:id   -> remove an item (needs the admin key)
 */
const SYSTEM =
  "You are a friendly, precise tutor for the GATE Mechanical Engineering exam (India). " +
  "Answer only study-related questions (engineering, mathematics, aptitude, exam strategy). " +
  "Use plain text without markdown headings or tables; write formulas in simple notation. " +
  "Be correct and concise, show worked numbers where useful, and mention common GATE traps.";

const SUBJECTS = ["aptitude","maths","mechanics","som","tom","vibrations","design","fluids","heat","thermo","manufacturing","industrial"];

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET,POST,DELETE,OPTIONS",
  "Access-Control-Allow-Headers": "content-type,x-device,x-admin-key",
};

function json(data, status = 200) {
  return new Response(JSON.stringify(data), { status, headers: { "content-type": "application/json", ...CORS } });
}

function isAdmin(req, env) {
  const k = req.headers.get("x-admin-key") || "";
  return !!env.ADMIN_KEY && k.length > 0 && k === env.ADMIN_KEY;
}

async function readList(env) {
  return JSON.parse((await env.GATE_KV.get("content")) || "[]");
}

const clip = (v, n) => String(v ?? "").slice(0, n);

export default {
  async fetch(req, env) {
    if (req.method === "OPTIONS") return new Response(null, { status: 204, headers: CORS });
    const url = new URL(req.url);
    const path = url.pathname.replace(/\/+$/, "") || "/";

    try {
      if (path === "/chat" && req.method === "POST") {
        const body = await req.json().catch(() => ({}));
        let messages = Array.isArray(body.messages) ? body.messages.slice(-12) : [];
        messages = messages
          .filter((m) => m && (m.role === "user" || m.role === "assistant") && typeof m.content === "string")
          .map((m) => ({ role: m.role, content: m.content.slice(0, 8000) }));
        while (messages.length && messages[0].role !== "user") messages.shift();
        if (!messages.length || messages[messages.length - 1].role !== "user") return json({ error: "Ask a question first." }, 400);

        const day = new Date().toISOString().slice(0, 10);
        const device = clip(req.headers.get("x-device") || "anon", 64);
        const perLimit = parseInt(env.DAILY_LIMIT || "30", 10);
        const allLimit = parseInt(env.GLOBAL_DAILY_LIMIT || "2000", 10);
        const kDev = `rl:${day}:${device}`, kAll = `rl:${day}:all`;
        const [nDev, nAll] = await Promise.all([env.GATE_KV.get(kDev), env.GATE_KV.get(kAll)]);
        if (parseInt(nDev || "0", 10) >= perLimit) return json({ error: `Daily limit of ${perLimit} questions reached. Try again tomorrow.` }, 429);
        if (parseInt(nAll || "0", 10) >= allLimit) return json({ error: "The tutor is busy today. Try again tomorrow." }, 429);

        const r = await fetch("https://api.anthropic.com/v1/messages", {
          method: "POST",
          headers: {
            "x-api-key": env.ANTHROPIC_API_KEY,
            "anthropic-version": "2023-06-01",
            "content-type": "application/json",
          },
          body: JSON.stringify({
            model: env.MODEL || "claude-haiku-5-5",
            max_tokens: parseInt(env.MAX_TOKENS || "1200", 10),
            system: SYSTEM,
            messages,
          }),
        });
        const data = await r.json().catch(() => ({}));
        if (!r.ok) return json({ error: "The tutor could not answer right now." }, 502);

        const opts = { expirationTtl: 60 * 60 * 48 };
        await Promise.all([
          env.GATE_KV.put(kDev, String(parseInt(nDev || "0", 10) + 1), opts),
          env.GATE_KV.put(kAll, String(parseInt(nAll || "0", 10) + 1), opts),
        ]);
        const text = (data.content || []).filter((b) => b.type === "text").map((b) => b.text).join("\n");
        return json({ text, truncated: data.stop_reason === "max_tokens" });
      }

      if (path === "/content" && req.method === "GET") {
        return json({ items: await readList(env) });
      }

      if (path === "/content" && req.method === "POST") {
        if (!isAdmin(req, env)) return json({ error: "wrong admin key" }, 401);
        const d = await req.json().catch(() => ({}));
        if (!SUBJECTS.includes(d.subject)) return json({ error: "unknown subject" }, 400);
        if (d.kind !== "pyq" && d.kind !== "note") return json({ error: "kind must be pyq or note" }, 400);
        if (!clip(d.question, 10).trim()) return json({ error: "question text is empty" }, 400);
        const item = {
          id: crypto.randomUUID(),
          subject: d.subject,
          kind: d.kind,
          year: clip(d.year, 80),
          marks: clip(d.marks, 60),
          title: clip(d.title, 200),
          question: clip(d.question, 6000),
          options: Array.isArray(d.options) ? d.options.slice(0, 8).map((o) => clip(o, 600)) : [],
          answer: clip(d.answer, 40),
          tol: clip(d.tol, 10),
          solution: clip(d.solution, 8000),
          createdAt: Number(d.createdAt) || Date.now(),
        };
        const list = await readList(env);
        list.push(item);
        await env.GATE_KV.put("content", JSON.stringify(list));
        return json({ id: item.id });
      }

      const m = path.match(/^\/content\/([\w-]+)$/);
      if (m && req.method === "DELETE") {
        if (!isAdmin(req, env)) return json({ error: "wrong admin key" }, 401);
        const list = (await readList(env)).filter((it) => it.id !== m[1]);
        await env.GATE_KV.put("content", JSON.stringify(list));
        return json({ ok: true });
      }

      if (path === "/") return json({ ok: true, service: "gate-me-notes" });
      return json({ error: "not found" }, 404);
    } catch (e) {
      return json({ error: "server error" }, 500);
    }
  },
};
