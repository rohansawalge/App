# GATE ME Notes – Android app

All the notes, 131 simulations, previous year questions, the "Ask a tutor" chatbot, and content you add later, in one Android app.
Students do NOT need a Claude account: the chatbot runs through your own small server, which holds your Claude API key.

```
gate-me-app/
  app/                     Android app (a WebView that shows the notes)
    src/main/assets/www/   the notes page + config.js + app-shim.js
  server/                  Cloudflare Worker: chatbot + content database
  tools/                   bulk import of PYQs / notes
  .github/workflows/       builds the APK on GitHub for you
```

You need about one hour the first time. Do the steps in order.

---

## Step 1 – Get a Claude API key (for the chatbot)

1. Go to https://console.anthropic.com and sign up.
2. Add billing credit, and set a monthly spend limit (Settings → Limits) so costs can never surprise you.
3. Create an API key (Settings → API keys). Copy it somewhere safe. Never put it inside the app.

Each chatbot answer costs a small amount of API usage. Check current model prices at https://docs.claude.com/en/api/overview before you share the app widely. The server uses `claude-haiku-5-5` (the cheapest model) by default; you can change `MODEL` in `server/wrangler.toml`.

## Step 2 – Deploy the server (free Cloudflare account)

1. Install Node.js (LTS) from https://nodejs.org.
2. Create a free account at https://dash.cloudflare.com.
3. Open a terminal in the `server` folder and run:

```
npx wrangler login
npx wrangler kv namespace create GATE_KV
```

4. The second command prints an `id`. Paste it into `server/wrangler.toml` in place of `PASTE_YOUR_KV_NAMESPACE_ID_HERE`.
5. Store your secrets (you will be asked to paste each one):

```
npx wrangler secret put ANTHROPIC_API_KEY
npx wrangler secret put ADMIN_KEY
```

`ADMIN_KEY` is a password you invent (make it long). Only someone with it can add or delete content.

6. Deploy:

```
npx wrangler deploy
```

It prints your server address, like `https://gate-me-tutor.yourname.workers.dev`. Open `<that address>/content` in a browser: you should see `{"items":[]}`.

## Step 3 – Point the app at your server

Edit `app/src/main/assets/www/config.js` and replace the placeholder with your server address:

```js
window.GATE_CONFIG = { API_URL: "https://gate-me-tutor.yourname.workers.dev" };
```

## Step 4 – Build the APK

**Option A: GitHub builds it for you (no Android Studio needed)**

1. Create a free GitHub account and a new **private** repository.
2. Upload the whole `gate-me-app` folder (GitHub Desktop is easiest; the web “Upload files” page also works).
3. Open the repository’s **Actions** tab. The “Build APK” workflow runs automatically (about 3–5 minutes).
4. Open the finished run and download **GATE-ME-Notes-apk**. Unzip it to get `app-debug.apk`.

**Option B: Android Studio**

Open the `gate-me-app` folder in Android Studio, wait for sync, then Build → Build App Bundle(s) / APK(s) → Build APK(s).

## Step 5 – Install on a phone

Copy `app-debug.apk` to the phone, tap it, and allow “Install unknown apps” when Android asks. Share the same APK file with students (WhatsApp, Drive, etc.).

## Adding PYQs and notes later (no app update needed)

**From the app:** on the Overview page, tap the big title 5 times, enter your `ADMIN_KEY`. An **Add content** form appears on the Overview page and a Delete button on every added item. New items appear for all students the next time they open the app (allow up to a minute).

**In bulk:** put items in a JSON file like `tools/content-example.json`, then run

```
node tools/import-content.mjs my-pyqs.json https://gate-me-tutor.yourname.workers.dev YOUR_ADMIN_KEY
```

Subjects: `aptitude, maths, mechanics, som, tom, vibrations, design, fluids, heat, thermo, manufacturing, industrial`. For a PYQ, give `options` with `answer` as a letter (A, B, C, D), or leave `options` out and give a numeric `answer` with `tol` (tolerance in %).

## Limits and costs you control

In `server/wrangler.toml`:

- `DAILY_LIMIT`: questions per phone per day (default 30)
- `GLOBAL_DAILY_LIMIT`: questions for all users per day (default 2000)
- `MAX_TOKENS`: maximum answer length

Change, then run `npx wrangler deploy` again. The per-phone limit is approximate (it is a light safeguard, not a security boundary); your Anthropic monthly spend limit is the hard cap.

## Updating the notes themselves

Changes to the notes, simulations or built-in PYQs live inside the app, so they need a new APK: replace `app/src/main/assets/www/index.html`, increase `versionCode` in `app/build.gradle.kts`, and rebuild. Content added through the server never needs a new APK.

## Publishing on Google Play (optional)

The GitHub build produces a debug APK, fine for sharing directly. For the Play Store you need a Google Play developer account (one-time registration fee), a release signing key, and an `.aab` bundle (`gradle bundleRelease` with signing configured). Ask when you get there.

## What works offline

All notes, simulations and built-in PYQs work offline. The chatbot and newly added content need internet (added content is cached after the first load).
